# MGS FS25 Schemas — initial development build

Extended Farming Simulator 25 XML schemas for editor completion and validation.

## Contents

- `upstream/giants/`: 88 unmodified XSD files supplied by the user.
- `extensions/interactive-control-reference.md`: supplied Interactive Control documentation.
- `scripts/build.py`: deterministic builder; copies upstream schemas and extends `vehicle.xsd`.
- `dist/fs25/`: generated XSDs for testing.

## Build

Install Python 3 and `lxml` (`pip install lxml`), then run `python scripts/build.py`.

## Local test

Temporarily set your vehicle XML's `xsi:noNamespaceSchemaLocation` to the absolute path of `dist/fs25/vehicle.xsd` using forward slashes. Check GIANTS XML diagnostics and Ctrl+Space. Restore the mod's original reference before publishing.

## GitHub hosting

After confirming redistribution rights, upload to a repository and try a raw GitHub URL to `dist/fs25/vehicle.xsd` in a **test copy** of the XML. Compatibility with the GIANTS extension's remote resolver is not yet verified. Do not assume GitHub Pages or raw URLs work until tested. Prefer versioned tags/releases to moving `main` URLs.

## Current coverage

- Interactive Control: control tree, click points, buttons, functions, restrictions, dashboards, dependencies, object changes, outdoor triggers, registrations and attributes transcribed from the supplied README.
- Vehicle Years: only `specs/year`, inferred from the user's diagnostic. No full Vehicle Years documentation was supplied.
- IC animation `part` attributes are not yet integrated; this needs a verified path-specific modification.

## Important limitations

- This is an **initial development build**, not a full integration-tested release. XSD compilation alone does not prove all real-world mods validate.
- The Interactive Control README explicitly says documentation is incomplete. Several attributes are deliberately typed as strings rather than guessing constraints.
- This repository does **not** contain the user's actual mod XML for end-to-end validation.
- GIANTS and Interactive Control files may have separate copyright/licensing restrictions. Do not publish third-party content publicly until redistribution permissions have been confirmed. If permission is unavailable, publish only original tooling/patch definitions and require users to supply upstream schemas locally.
