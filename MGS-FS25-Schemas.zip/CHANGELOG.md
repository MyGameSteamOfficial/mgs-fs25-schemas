# Changelog

## 0.1.0-dev

- Imported 88 supplied GIANTS schema files unchanged.
- Added deterministic vehicle XSD build script.
- Added preliminary Interactive Control schema definitions based on supplied README.
- Added preliminary Vehicle Years `specs/year` element.
- Compiled generated XSD successfully.
